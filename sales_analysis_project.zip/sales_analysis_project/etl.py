"""Step 2: Read the Excel file, clean it with pandas, and load it into SQLite."""
import sqlite3
import pandas as pd
from pathlib import Path

EXCEL = "data/sales_data.xlsx"
DB = "data/sales.db"
SCHEMA = "sql/schema.sql"


def clean(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.drop_duplicates().copy()
    print(f"Removed {before - len(df)} duplicate rows")

    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    df["order_date"] = pd.to_datetime(df["order_date"])

    missing = df["discount"].isna().sum()
    df["discount"] = df["discount"].fillna(0.0)
    print(f"Filled {missing} missing discounts with 0")

    # Derived columns used by the SQL queries
    df["order_month"] = df["order_date"].dt.strftime("%Y-%m")
    df["order_year"] = df["order_date"].dt.year
    df["order_date"] = df["order_date"].dt.strftime("%Y-%m-%d")
    return df


def main():
    df = clean(pd.read_excel(EXCEL, sheet_name="Sales"))

    Path(DB).unlink(missing_ok=True)
    con = sqlite3.connect(DB)
    con.executescript(Path(SCHEMA).read_text())
    df.to_sql("sales", con, if_exists="append", index=False)
    con.commit()
    n = con.execute("SELECT COUNT(*) FROM sales").fetchone()[0]
    print(f"Loaded {n} rows into {DB}")
    con.close()


if __name__ == "__main__":
    main()

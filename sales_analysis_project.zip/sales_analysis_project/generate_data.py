"""Step 1: Generate a dummy sales dataset and save it as an Excel file."""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
N = 5000

products = {
    "Laptop":        ("Electronics", 55000),
    "Smartphone":    ("Electronics", 30000),
    "Headphones":    ("Electronics", 3500),
    "Office Chair":  ("Furniture", 9000),
    "Desk":          ("Furniture", 14000),
    "Notebook Pack": ("Stationery", 400),
    "Pen Set":       ("Stationery", 250),
    "Backpack":      ("Accessories", 2200),
    "Water Bottle":  ("Accessories", 600),
}
regions = {
    "North": ["Delhi", "Chandigarh"],
    "South": ["Bengaluru", "Chennai"],
    "East":  ["Kolkata", "Bhubaneswar"],
    "West":  ["Mumbai", "Pune"],
}
segments = ["Consumer", "Corporate", "Small Business"]

names = list(products)
prod = rng.choice(names, N, p=[.08, .12, .15, .07, .05, .18, .15, .10, .10])
region = rng.choice(list(regions), N, p=[.2, .3, .15, .35])
city = [rng.choice(regions[r]) for r in region]
dates = pd.to_datetime("2024-01-01") + pd.to_timedelta(rng.integers(0, 730, N), unit="D")

df = pd.DataFrame({
    "Order ID": [f"ORD-{100000 + i}" for i in range(N)],
    "Order Date": dates,
    "Customer ID": [f"CUST-{rng.integers(1, 1200):04d}" for _ in range(N)],
    "Segment": rng.choice(segments, N, p=[.55, .3, .15]),
    "Region": region,
    "City": city,
    "Product": prod,
    "Category": [products[p][0] for p in prod],
    "Unit Price": [products[p][1] for p in prod],
    "Quantity": rng.integers(1, 6, N),
    "Discount": rng.choice([0, 0.05, 0.1, 0.15, 0.2], N, p=[.4, .25, .2, .1, .05]),
})
df["Sales"] = (df["Unit Price"] * df["Quantity"] * (1 - df["Discount"])).round(2)
cost_ratio = rng.uniform(0.6, 0.85, N)
df["Profit"] = (df["Sales"] - df["Unit Price"] * df["Quantity"] * cost_ratio).round(2)
df = df.sort_values("Order Date").reset_index(drop=True)

# Add a little mess so the cleaning step has something to do
df.loc[rng.choice(N, 25, replace=False), "Discount"] = np.nan
dupes = df.sample(15, random_state=1)
df = pd.concat([df, dupes], ignore_index=True)

Path("data").mkdir(exist_ok=True)
df.to_excel("data/sales_data.xlsx", index=False, sheet_name="Sales")
print(f"Wrote data/sales_data.xlsx with {len(df)} rows")

"""Step 3: Run the SQL queries, print results, save CSVs and charts."""
import re
import sqlite3
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

DB = "data/sales.db"
OUT = Path("outputs")
OUT.mkdir(exist_ok=True)


def load_queries(path="sql/queries.sql") -> dict:
    text = Path(path).read_text()
    parts = re.split(r"^-- name:\s*(\w+)\s*$", text, flags=re.M)
    return {parts[i]: parts[i + 1].strip() for i in range(1, len(parts), 2)}


def main():
    con = sqlite3.connect(DB)
    queries = load_queries()
    res = {name: pd.read_sql_query(sql, con) for name, sql in queries.items()}
    con.close()

    for name, df in res.items():
        df.to_csv(OUT / f"{name}.csv", index=False)
        print(f"\n=== {name} ===\n{df.to_string(index=False)}")

    plt.rcParams.update({"axes.spines.top": False, "axes.spines.right": False,
                         "figure.dpi": 120})
    blue, orange = "#2a6fdb", "#e8833a"

    # 1. Monthly sales trend
    m = res["monthly_sales"]
    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.plot(m["order_month"], m["sales"] / 1e6, color=blue, marker="o", label="Sales")
    ax.plot(m["order_month"], m["profit"] / 1e6, color=orange, marker="o", label="Profit")
    ax.set_title("Monthly sales and profit"); ax.set_ylabel("INR millions")
    ax.set_xticks(range(0, len(m), 2)); ax.set_xticklabels(m["order_month"][::2], rotation=45)
    ax.legend(frameon=False); fig.tight_layout(); fig.savefig(OUT / "monthly_trend.png"); plt.close(fig)

    # 2. Sales by region and category
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    r = res["sales_by_region"]
    axes[0].bar(r["region"], r["sales"] / 1e6, color=blue)
    axes[0].set_title("Sales by region"); axes[0].set_ylabel("INR millions")
    c = res["sales_by_category"]
    axes[1].bar(c["category"], c["sales"] / 1e6, color=blue)
    axes[1].set_title("Sales by category")
    fig.tight_layout(); fig.savefig(OUT / "region_category.png"); plt.close(fig)

    # 3. Top products
    t = res["top_products"].sort_values("sales")
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.barh(t["product"], t["sales"] / 1e6, color=blue)
    ax.set_title("Top products by sales"); ax.set_xlabel("INR millions")
    fig.tight_layout(); fig.savefig(OUT / "top_products.png"); plt.close(fig)

    # 4. Discount impact on margin
    d = res["discount_impact"]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.bar(d["discount_level"], d["margin_pct"], color=orange)
    ax.set_title("Profit margin by discount level"); ax.set_ylabel("Margin %")
    fig.tight_layout(); fig.savefig(OUT / "discount_margin.png"); plt.close(fig)

    print(f"\nSaved CSVs and charts to {OUT}/")


if __name__ == "__main__":
    main()

# Sales Data Analysis (Excel + Python + SQL)

An end-to-end analysis project: an Excel sales dataset is cleaned with Python (pandas), loaded into a SQLite database, queried with SQL, and summarised with charts.

The data is synthetic (5,000 orders, Jan 2024 to Dec 2025, four Indian regions, nine products) and includes a few duplicates and missing values so the cleaning step is real.

## Project structure

```
sales_analysis_project/
├── generate_data.py      # 1. creates data/sales_data.xlsx (dummy data)
├── etl.py                # 2. cleans the Excel data and loads it into SQLite
├── analysis.py           # 3. runs the SQL queries, saves CSVs and charts
├── sql/
│   ├── schema.sql        # table definition and indexes
│   └── queries.sql       # 13 named analysis queries
├── data/                 # sales_data.xlsx, sales.db
├── outputs/              # query result CSVs and PNG charts
└── requirements.txt
```

## How to run

```bash
pip install -r requirements.txt
python generate_data.py   # skip this if you use your own Excel file
python etl.py
python analysis.py
```

To use your own Excel file, replace `data/sales_data.xlsx` (sheet name `Sales`) and keep the same column names, or edit the column mapping in `etl.py` and `sql/schema.sql`.

## What the SQL covers

| Query | Techniques |
|---|---|
| kpis | aggregates, ratios |
| monthly_sales, sales_by_region, sales_by_category | GROUP BY, subquery for share of total |
| yoy_growth | self join on month, growth percentage |
| top_products | RANK() window function |
| running_total | CTE and cumulative SUM() OVER |
| top_customers, top_cities, segment_performance | multi-column grouping, LIMIT |
| discount_impact | profit margin by discount tier |
| repeat_customers | nested subquery with CASE |

## Key findings (on the dummy data)

- Total sales are about INR 144M with a 23.6% profit margin across 5,000 orders and 1,182 customers.
- Electronics drives roughly 83% of revenue; Laptops and Smartphones alone are about 78%.
- West is the largest region (35% of sales), with Mumbai and Pune as the top two cities.
- Margin falls steadily as discounts rise: 27.7% at no discount versus 10.3% at 20%.
- Monthly sales are noisy, with Q4 2025 notably stronger than Q4 2024.

Because the data is randomly generated, treat these as a demonstration of the method, not real business insight.

## Ideas to extend

- Add customer RFM segmentation in SQL.
- Build a Streamlit or Power BI dashboard on top of `sales.db`.
- Add a sales forecast using the monthly series.

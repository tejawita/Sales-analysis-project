-- Each query starts with a "-- name: <id>" line so analysis.py can run them by name.

-- name: kpis
SELECT COUNT(*)                          AS total_orders,
       COUNT(DISTINCT customer_id)       AS total_customers,
       ROUND(SUM(sales), 2)              AS total_sales,
       ROUND(SUM(profit), 2)             AS total_profit,
       ROUND(100.0 * SUM(profit) / SUM(sales), 2) AS profit_margin_pct,
       ROUND(AVG(sales), 2)              AS avg_order_value
FROM sales;

-- name: monthly_sales
SELECT order_month,
       ROUND(SUM(sales), 2)  AS sales,
       ROUND(SUM(profit), 2) AS profit,
       COUNT(*)              AS orders
FROM sales
GROUP BY order_month
ORDER BY order_month;

-- name: yoy_growth
-- Year-over-year growth by month using a self join
SELECT cur.month_num,
       ROUND(prev.sales, 2) AS sales_2024,
       ROUND(cur.sales, 2)  AS sales_2025,
       ROUND(100.0 * (cur.sales - prev.sales) / prev.sales, 2) AS yoy_growth_pct
FROM (SELECT SUBSTR(order_month, 6, 2) AS month_num, SUM(sales) AS sales
      FROM sales WHERE order_year = 2025 GROUP BY month_num) cur
JOIN (SELECT SUBSTR(order_month, 6, 2) AS month_num, SUM(sales) AS sales
      FROM sales WHERE order_year = 2024 GROUP BY month_num) prev
  ON cur.month_num = prev.month_num
ORDER BY cur.month_num;

-- name: sales_by_region
SELECT region,
       ROUND(SUM(sales), 2)  AS sales,
       ROUND(SUM(profit), 2) AS profit,
       ROUND(100.0 * SUM(sales) / (SELECT SUM(sales) FROM sales), 2) AS share_pct
FROM sales
GROUP BY region
ORDER BY sales DESC;

-- name: sales_by_category
SELECT category,
       ROUND(SUM(sales), 2)  AS sales,
       ROUND(SUM(profit), 2) AS profit,
       ROUND(100.0 * SUM(profit) / SUM(sales), 2) AS margin_pct
FROM sales
GROUP BY category
ORDER BY sales DESC;

-- name: top_products
SELECT product,
       category,
       SUM(quantity)         AS units_sold,
       ROUND(SUM(sales), 2)  AS sales,
       ROUND(SUM(profit), 2) AS profit,
       RANK() OVER (ORDER BY SUM(sales) DESC) AS sales_rank
FROM sales
GROUP BY product, category
ORDER BY sales_rank
LIMIT 10;

-- name: top_cities
SELECT city, region, ROUND(SUM(sales), 2) AS sales
FROM sales
GROUP BY city, region
ORDER BY sales DESC
LIMIT 5;

-- name: top_customers
SELECT customer_id,
       segment,
       COUNT(*)             AS orders,
       ROUND(SUM(sales), 2) AS total_spent
FROM sales
GROUP BY customer_id, segment
ORDER BY total_spent DESC
LIMIT 10;

-- name: segment_performance
SELECT segment,
       COUNT(DISTINCT customer_id) AS customers,
       COUNT(*)                    AS orders,
       ROUND(SUM(sales), 2)        AS sales,
       ROUND(AVG(sales), 2)        AS avg_order_value
FROM sales
GROUP BY segment
ORDER BY sales DESC;

-- name: discount_impact
SELECT CAST(discount * 100 AS INT) || '%' AS discount_level,
       COUNT(*)                            AS orders,
       ROUND(AVG(sales), 2)                AS avg_sales,
       ROUND(100.0 * SUM(profit) / SUM(sales), 2) AS margin_pct
FROM sales
GROUP BY discount
ORDER BY discount;

-- name: running_total
-- Cumulative sales using a window function over monthly totals
WITH m AS (
    SELECT order_month, SUM(sales) AS sales FROM sales GROUP BY order_month
)
SELECT order_month,
       ROUND(sales, 2) AS sales,
       ROUND(SUM(sales) OVER (ORDER BY order_month), 2) AS cumulative_sales
FROM m
ORDER BY order_month;

-- name: repeat_customers
-- Share of customers with more than one order
SELECT ROUND(100.0 * SUM(CASE WHEN n > 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS repeat_customer_pct
FROM (SELECT customer_id, COUNT(*) AS n FROM sales GROUP BY customer_id);

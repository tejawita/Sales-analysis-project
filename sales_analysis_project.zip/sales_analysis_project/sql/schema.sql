CREATE TABLE sales (
    order_id     TEXT PRIMARY KEY,
    order_date   TEXT NOT NULL,
    customer_id  TEXT NOT NULL,
    segment      TEXT,
    region       TEXT,
    city         TEXT,
    product      TEXT,
    category     TEXT,
    unit_price   REAL,
    quantity     INTEGER,
    discount     REAL DEFAULT 0,
    sales        REAL,
    profit       REAL,
    order_month  TEXT,
    order_year   INTEGER
);

CREATE INDEX idx_sales_month    ON sales(order_month);
CREATE INDEX idx_sales_region   ON sales(region);
CREATE INDEX idx_sales_customer ON sales(customer_id);
